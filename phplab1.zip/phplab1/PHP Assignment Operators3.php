<!DOCTYPE html>
<html>
<body>

<?php
$x = 50;
$x -= 30;

echo $x;
?>  

</body>
</html>
