<!DOCTYPE html>
<html>
<body>

<?php  
$x = 10.365;
var_dump($x);
?>  

</body>
</html>
