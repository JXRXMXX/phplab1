<!DOCTYPE html>
<html>
<body>

<?php
echo(rand(10, 100));
?>

</body>
</html>
