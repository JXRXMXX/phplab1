<!DOCTYPE html>
<html>
<body>

<?php
$x = 100;  

if ($x !== 90) {
    echo "Hello world!";
}
?>  

</body>
</html>
