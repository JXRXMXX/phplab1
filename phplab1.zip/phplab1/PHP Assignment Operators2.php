<!DOCTYPE html>
<html>
<body>

<?php
$x = 20;  
$x += 100;

echo $x;
?>  

</body>
</html>
