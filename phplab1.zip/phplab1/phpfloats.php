<!DOCTYPE html>
<html>
<body>

<?php
// Check if the type of a variable is float 
$x = 10.365;
var_dump(is_float($x));
?>  

</body>
</html>
