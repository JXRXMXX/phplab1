<!DOCTYPE html>
<html>
<body>

<?php  
$x = 5985;
var_dump($x);
?>  

</body>
</html>
