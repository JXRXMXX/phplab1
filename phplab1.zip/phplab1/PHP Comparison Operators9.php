<!DOCTYPE html>
<html>
<body>

<?php
$x = 50;
$y = 50;

var_dump($x <= $y); // returns true because $x is less than or equal to $y
?>  

</body>
</html>
